package com.fidel.misbolsillos
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
