// lib/services/drive_service.dart
import 'dart:convert';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart' as http;

class DriveService {
  static final _gsi = GoogleSignIn(scopes: ['email', 'https://www.googleapis.com/auth/drive.file']);
  static GoogleSignInAccount? _user;
  static GoogleSignInAccount? get currentUser => _user;
  static bool get isSignedIn => _user != null;

  static Future<GoogleSignInAccount?> signIn() async {
    try { _user = await _gsi.signIn(); return _user; } catch (_) { return null; }
  }
  static Future<void> signOut() async { await _gsi.signOut(); _user = null; }
  static Future<void> signInSilently() async {
    try { _user = await _gsi.signInSilently(); } catch (_) {}
  }

  static Future<Map<String, String>?> _headers() async {
    if (_user == null) return null;
    final auth = await _user!.authentication;
    return {'Authorization': 'Bearer ${auth.accessToken}', 'Content-Type': 'application/json'};
  }

  static Future<String?> _getOrCreateFolder() async {
    final h = await _headers(); if (h == null) return null;
    final res = await http.get(Uri.parse(
      "https://www.googleapis.com/drive/v3/files?q=name='Mis Bolsillos' and mimeType='application/vnd.google-apps.folder' and trashed=false&fields=files(id)"), headers: h);
    if (res.statusCode == 200) {
      final files = jsonDecode(res.body)['files'] as List;
      if (files.isNotEmpty) return files[0]['id'];
    }
    final cr = await http.post(Uri.parse('https://www.googleapis.com/drive/v3/files'), headers: h,
      body: jsonEncode({'name': 'Mis Bolsillos', 'mimeType': 'application/vnd.google-apps.folder'}));
    return cr.statusCode == 200 ? jsonDecode(cr.body)['id'] : null;
  }

  static Future<bool> uploadCSV(String csv, String filename) async {
    final h = await _headers(); if (h == null) return false;
    final folderId = await _getOrCreateFolder(); if (folderId == null) return false;
    final sr = await http.get(Uri.parse(
      "https://www.googleapis.com/drive/v3/files?q=name='$filename' and '$folderId' in parents and trashed=false&fields=files(id)"), headers: h);
    String? existId;
    if (sr.statusCode == 200) {
      final files = jsonDecode(sr.body)['files'] as List;
      if (files.isNotEmpty) existId = files[0]['id'];
    }
    final boundary = 'boundary314159';
    final meta = existId == null
        ? jsonEncode({'name': filename, 'parents': [folderId], 'mimeType': 'text/csv'})
        : jsonEncode({'name': filename});
    final body = '--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$meta\r\n--$boundary\r\nContent-Type: text/csv\r\n\r\n$csv\r\n--$boundary--';
    final uh = {...h, 'Content-Type': 'multipart/related; boundary=$boundary'};
    final res = existId != null
        ? await http.patch(Uri.parse('https://www.googleapis.com/upload/drive/v3/files/$existId?uploadType=multipart'), headers: uh, body: body)
        : await http.post(Uri.parse('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart'), headers: uh, body: body);
    return res.statusCode == 200;
  }
}
