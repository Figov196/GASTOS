// lib/screens/config_screen.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../models.dart';
import '../services/drive_service.dart';
import '../state.dart';
import '../theme.dart';

class ConfigScreen extends StatefulWidget {
  const ConfigScreen({super.key});
  @override
  State<ConfigScreen> createState() => _ConfigScreenState();
}

class _ConfigScreenState extends State<ConfigScreen> with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;
  bool _syncing = false;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() { _tabCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Container(color: kS1, child: TabBar(
        controller: _tabCtrl,
        labelColor: kAccent,
        unselectedLabelColor: kMuted,
        indicatorColor: kAccent,
        labelStyle: const TextStyle(fontSize: 12, fontFamily: 'DM Mono'),
        tabs: const [Tab(text: 'Categorías'), Tab(text: 'Porcentajes'), Tab(text: 'Datos')],
      )),
      Expanded(child: TabBarView(controller: _tabCtrl, children: [
        _CategoriasTab(),
        _PorcentajesTab(),
        _DatosTab(syncing: _syncing, onSyncChange: (v) => setState(() => _syncing = v)),
      ])),
    ]);
  }
}

// ===================== TAB 1: CATEGORÍAS =====================
class _CategoriasTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final prov = context.watch<BolsillosProvider>();
    final cats = prov.s.cats;

    return Column(children: [
      Padding(padding: const EdgeInsets.all(16), child: Row(children: [
        Expanded(child: Text('${cats.length} categorías', style: syneStyle(size: 13, color: kMuted))),
        ElevatedButton.icon(
          icon: const Icon(Icons.add, size: 16),
          label: const Text('Nueva', style: TextStyle(fontSize: 13)),
          onPressed: () => _showAddDialog(context, prov),
          style: ElevatedButton.styleFrom(backgroundColor: kAccent, foregroundColor: Colors.black,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
        ),
      ])),
      Expanded(child: ReorderableListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        itemCount: cats.length,
        onReorder: prov.reorderCategorias,
        itemBuilder: (_, i) {
          final cat = cats[i];
          final color = Color(cat.color);
          return Container(
            key: ValueKey(cat.n + i.toString()),
            margin: const EdgeInsets.only(bottom: 8),
            decoration: BoxDecoration(
              color: kS1, borderRadius: BorderRadius.circular(12),
              border: Border.all(color: color.withOpacity(0.2))),
            child: ListTile(
              leading: Container(width: 12, height: 12,
                decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
              title: Text(cat.n, style: const TextStyle(fontSize: 13)),
              subtitle: Text(cat.seg ? 'Calculado automáticamente' : '${cat.pct.toStringAsFixed(0)}%',
                style: TextStyle(fontSize: 11, color: cat.seg ? kA3 : kMuted)),
              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                if (!cat.seg) IconButton(
                  icon: const Icon(Icons.delete_outline, size: 18, color: kDanger),
                  onPressed: () => _confirmDelete(context, prov, i, cat.n),
                ),
                const Icon(Icons.drag_handle, color: kMuted, size: 20),
              ]),
            ),
          );
        },
      )),
    ]);
  }

  void _showAddDialog(BuildContext context, BolsillosProvider prov) {
    final nameCtrl = TextEditingController();
    final pctCtrl = TextEditingController(text: '0');
    int selectedColor = catColors[0];

    showDialog(context: context, builder: (ctx) => StatefulBuilder(
      builder: (ctx, setS) => AlertDialog(
        backgroundColor: kS2,
        title: Text('Nueva categoría', style: syneStyle(size: 16)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: nameCtrl,
            style: const TextStyle(fontSize: 14),
            decoration: const InputDecoration(labelText: 'Nombre', filled: true, fillColor: kS3)),
          const SizedBox(height: 12),
          TextField(controller: pctCtrl, keyboardType: TextInputType.number,
            style: const TextStyle(fontSize: 14),
            decoration: const InputDecoration(labelText: 'Porcentaje (%)', filled: true, fillColor: kS3, suffixText: '%')),
          const SizedBox(height: 12),
          const Align(alignment: Alignment.centerLeft,
            child: Text('Color:', style: TextStyle(fontSize: 12, color: kMuted))),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: catColors.map((c) {
            final selected = c == selectedColor;
            return GestureDetector(
              onTap: () => setS(() => selectedColor = c),
              child: Container(width: 28, height: 28,
                decoration: BoxDecoration(
                  color: Color(c), shape: BoxShape.circle,
                  border: Border.all(color: selected ? kText : Colors.transparent, width: 2))),
            );
          }).toList()),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancelar', style: TextStyle(color: kMuted))),
          ElevatedButton(
            onPressed: () {
              final name = nameCtrl.text.trim();
              final pct = double.tryParse(pctCtrl.text) ?? 0;
              if (name.isEmpty) return;
              prov.addCategoria(name, pct, selectedColor);
              Navigator.pop(ctx);
            },
            style: ElevatedButton.styleFrom(backgroundColor: kAccent, foregroundColor: Colors.black),
            child: Text('Agregar', style: syneStyle(size: 13, color: Colors.black)),
          ),
        ],
      ),
    ));
  }

  void _confirmDelete(BuildContext context, BolsillosProvider prov, int idx, String nombre) {
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: kS2,
      title: Text('¿Eliminar "$nombre"?', style: syneStyle(size: 15)),
      content: const Text('Los movimientos registrados en esta categoría se conservan pero ya no se mostrarán en el resumen.',
        style: TextStyle(fontSize: 12, color: kMuted, height: 1.6)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context),
          child: const Text('Cancelar', style: TextStyle(color: kMuted))),
        ElevatedButton(
          onPressed: () { prov.deleteCategoria(idx); Navigator.pop(context); },
          style: ElevatedButton.styleFrom(backgroundColor: kDanger),
          child: Text('Eliminar', style: syneStyle(size: 13, color: Colors.white))),
      ],
    ));
  }
}

// ===================== TAB 2: PORCENTAJES =====================
class _PorcentajesTab extends StatefulWidget {
  @override
  State<_PorcentajesTab> createState() => _PorcentajesTabState();
}

class _PorcentajesTabState extends State<_PorcentajesTab> {
  Map<int, TextEditingController> _ctrls = {};

  @override
  void dispose() {
    for (final c in _ctrls.values) c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final prov = context.watch<BolsillosProvider>();
    final cats = prov.s.cats;

    // Sync controllers
    for (var i = 0; i < cats.length; i++) {
      _ctrls[i] ??= TextEditingController(text: cats[i].pct.toStringAsFixed(0));
    }
    // Remove old controllers
    _ctrls.removeWhere((k, v) { if (k >= cats.length) { v.dispose(); return true; } return false; });

    final total = _ctrls.entries
        .where((e) => e.key < cats.length && !cats[e.key].seg)
        .map((e) => double.tryParse(e.value.text) ?? 0)
        .fold(0.0, (a, b) => a + b);
    final ok = (total - 100).abs() < 0.1;

    return ListView(padding: const EdgeInsets.all(16), children: [
      Container(padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: kS2, borderRadius: BorderRadius.circular(10), border: Border.all(color: kBorder)),
        child: const Text('Ajusta cuánto % del ingreso va a cada bolsillo. Los porcentajes deben sumar 100%.',
          style: TextStyle(fontSize: 12, color: kMuted, height: 1.6))),
      const SizedBox(height: 14),
      ...cats.asMap().entries.map((e) {
        final i = e.key; final cat = e.value;
        final color = Color(cat.color);
        return Padding(padding: const EdgeInsets.only(bottom: 10),
          child: Row(children: [
            Container(width: 8, height: 8, margin: const EdgeInsets.only(right: 10),
              decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
            Expanded(child: Text(cat.n, style: const TextStyle(fontSize: 13))),
            if (cat.seg)
              Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                decoration: BoxDecoration(color: kS2, borderRadius: BorderRadius.circular(6)),
                child: const Text('auto', style: TextStyle(fontSize: 12, color: kA3)))
            else ...[
              SizedBox(width: 70, child: TextField(
                controller: _ctrls[i],
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                textAlign: TextAlign.right,
                style: syneStyle(size: 15, color: kAccent),
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 8)),
              )),
              const SizedBox(width: 4),
              const Text('%', style: TextStyle(color: kMuted, fontSize: 13)),
            ],
          ]));
      }),
      const Divider(),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text('Total:', style: syneStyle(size: 13, color: kMuted)),
        Text('${total.toStringAsFixed(1)}%', style: syneStyle(size: 16, color: ok ? kAccent : kDanger)),
      ]),
      const SizedBox(height: 14),
      SizedBox(width: double.infinity,
        child: ElevatedButton(
          onPressed: ok ? () {
            final newCats = prov.s.cats.asMap().entries.map((e) {
              final c = Categoria(n: e.value.n, pct: e.value.pct, seg: e.value.seg, color: e.value.color);
              if (!c.seg) c.pct = double.tryParse(_ctrls[e.key]?.text ?? '0') ?? c.pct;
              return c;
            }).toList();
            prov.saveCats(newCats);
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
              content: Text('Distribución guardada ✓'), backgroundColor: kAccent));
          } : null,
          style: ElevatedButton.styleFrom(backgroundColor: kAccent, foregroundColor: Colors.black,
            disabledBackgroundColor: kS3,
            padding: const EdgeInsets.symmetric(vertical: 14),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
          child: Text('Guardar distribución', style: syneStyle(size: 13, color: ok ? Colors.black : kMuted)),
        )),
    ]);
  }
}

// ===================== TAB 3: DATOS =====================
class _DatosTab extends StatelessWidget {
  final bool syncing;
  final ValueChanged<bool> onSyncChange;
  const _DatosTab({required this.syncing, required this.onSyncChange});

  @override
  Widget build(BuildContext context) {
    final prov = context.watch<BolsillosProvider>();
    final isSignedIn = DriveService.isSignedIn;
    final user = DriveService.currentUser;

    return ListView(padding: const EdgeInsets.all(16), children: [
      // GOOGLE DRIVE
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(width: 7, height: 7, decoration: const BoxDecoration(color: kA2, shape: BoxShape.circle)),
            const SizedBox(width: 8), Text('Google Drive', style: syneStyle(size: 13)),
          ]),
          const SizedBox(height: 14),
          if (isSignedIn) ...[
            Row(children: [
              CircleAvatar(radius: 16, backgroundColor: kS3,
                backgroundImage: user?.photoUrl != null ? NetworkImage(user!.photoUrl!) : null,
                child: user?.photoUrl == null ? const Icon(Icons.person, size: 16, color: kMuted) : null),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(user?.displayName ?? '', style: const TextStyle(fontSize: 13)),
                Text(user?.email ?? '', style: const TextStyle(fontSize: 11, color: kMuted)),
              ])),
              TextButton(onPressed: () async { await DriveService.signOut(); (context as Element).markNeedsBuild(); },
                child: const Text('Salir', style: TextStyle(color: kDanger, fontSize: 12))),
            ]),
            const SizedBox(height: 14),
            SizedBox(width: double.infinity, child: ElevatedButton.icon(
              icon: syncing ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                : const Icon(Icons.cloud_upload_outlined, size: 18),
              label: Text(syncing ? 'Subiendo...' : 'Guardar CSV en Drive',
                style: syneStyle(size: 13, color: Colors.black)),
              onPressed: syncing ? null : () => _syncDrive(context, prov),
              style: ElevatedButton.styleFrom(backgroundColor: kA2, foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(vertical: 13),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            )),
          ] else ...[
            const Text('Inicia sesión para guardar el CSV en tu Drive automáticamente.',
              style: TextStyle(fontSize: 12, color: kMuted, height: 1.6)),
            const SizedBox(height: 14),
            SizedBox(width: double.infinity, child: ElevatedButton.icon(
              icon: const Icon(Icons.login, size: 18),
              label: Text('Iniciar sesión con Google', style: syneStyle(size: 13, color: Colors.black)),
              onPressed: () async {
                final u = await DriveService.signIn();
                if (u == null && context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                    content: Text('No se pudo iniciar sesión'), backgroundColor: kDanger));
                }
              },
              style: ElevatedButton.styleFrom(backgroundColor: kAccent, foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(vertical: 13),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            )),
          ],
          const SizedBox(height: 10),
          SizedBox(width: double.infinity, child: OutlinedButton.icon(
            icon: const Icon(Icons.share_outlined, size: 16),
            label: const Text('Compartir CSV', style: TextStyle(fontSize: 13)),
            onPressed: () => _shareCSV(context, prov),
            style: OutlinedButton.styleFrom(foregroundColor: kMuted,
              side: const BorderSide(color: kBorder),
              padding: const EdgeInsets.symmetric(vertical: 12),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
          )),
        ],
      ))),

      // ZONA PELIGROSA
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(width: 7, height: 7, decoration: const BoxDecoration(color: kDanger, shape: BoxShape.circle)),
            const SizedBox(width: 8), Text('Zona peligrosa', style: syneStyle(size: 13)),
          ]),
          const SizedBox(height: 14),
          SizedBox(width: double.infinity, child: ElevatedButton(
            onPressed: () => _confirmarBorrar(context, prov),
            style: ElevatedButton.styleFrom(
              backgroundColor: kDanger.withOpacity(0.15), foregroundColor: kDanger,
              padding: const EdgeInsets.symmetric(vertical: 13),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10), side: const BorderSide(color: kDanger))),
            child: Text('Borrar datos de este mes', style: syneStyle(size: 13, color: kDanger)),
          )),
        ],
      ))),
      const SizedBox(height: 20),
    ]);
  }

  Future<void> _syncDrive(BuildContext context, BolsillosProvider prov) async {
    onSyncChange(true);
    final csv = prov.buildCSV();
    final fecha = DateTime.now().toIso8601String().split('T')[0];
    final ok = await DriveService.uploadCSV(csv, 'MisBolsillos_$fecha.csv');
    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(ok ? '✓ Guardado en carpeta "Mis Bolsillos" de tu Drive' : 'Error al subir a Drive'),
      backgroundColor: ok ? kAccent : kDanger, duration: const Duration(seconds: 3)));
    onSyncChange(false);
  }

  Future<void> _shareCSV(BuildContext context, BolsillosProvider prov) async {
    final csv = prov.buildCSV();
    final dir = await getTemporaryDirectory();
    final fecha = DateTime.now().toIso8601String().split('T')[0];
    final file = File('${dir.path}/MisBolsillos_$fecha.csv');
    await file.writeAsString(csv);
    await Share.shareXFiles([XFile(file.path)], text: 'Mis Bolsillos — CSV');
  }

  void _confirmarBorrar(BuildContext context, BolsillosProvider prov) {
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: kS2,
      title: Text('¿Borrar este mes?', style: syneStyle(size: 16)),
      content: const Text('Se eliminarán todos los movimientos e ingresos del mes seleccionado.',
        style: TextStyle(color: kMuted, fontSize: 13)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context),
          child: const Text('Cancelar', style: TextStyle(color: kMuted))),
        ElevatedButton(onPressed: () { prov.borrarMes(); Navigator.pop(context); },
          style: ElevatedButton.styleFrom(backgroundColor: kDanger),
          child: Text('Borrar', style: syneStyle(size: 13, color: Colors.white))),
      ],
    ));
  }
}
