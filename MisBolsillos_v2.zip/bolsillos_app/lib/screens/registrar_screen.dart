// lib/screens/registrar_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/mes_selector.dart';

class RegistrarScreen extends StatefulWidget {
  const RegistrarScreen({super.key});
  @override
  State<RegistrarScreen> createState() => _RegistrarScreenState();
}

class _RegistrarScreenState extends State<RegistrarScreen> {
  String _tipo = 'Gasto';
  String? _cat;
  final _detCtrl = TextEditingController();
  final _valCtrl = TextEditingController();

  @override
  void dispose() { _detCtrl.dispose(); _valCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final prov = context.watch<BolsillosProvider>();
    final cats = prov.s.cats.map((c) => c.n).toList();
    if (_cat == null || !cats.contains(_cat)) _cat = cats.first;

    return ListView(padding: const EdgeInsets.all(16), children: [
      const MesSelector(),
      const SizedBox(height: 16),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(width: 7, height: 7, decoration: const BoxDecoration(color: kA2, shape: BoxShape.circle)),
            const SizedBox(width: 8),
            Text('Nuevo movimiento', style: syneStyle(size: 13)),
          ]),
          const SizedBox(height: 16),
          Row(children: [
            _TipoBtn('Gasto', _tipo == 'Gasto', kDanger, () => setState(() => _tipo = 'Gasto')),
            const SizedBox(width: 10),
            _TipoBtn('Ingreso', _tipo == 'Ingreso', kAccent, () => setState(() => _tipo = 'Ingreso')),
          ]),
          const SizedBox(height: 14),
          const Text('CATEGORÍA', style: TextStyle(fontSize: 10, color: kMuted, letterSpacing: 1)),
          const SizedBox(height: 6),
          DropdownButtonFormField<String>(
            value: _cat, dropdownColor: kS2,
            style: const TextStyle(color: kText, fontSize: 13, fontFamily: 'DM Mono'),
            items: cats.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _cat = v),
            decoration: const InputDecoration(),
          ),
          const SizedBox(height: 14),
          const Text('DETALLE', style: TextStyle(fontSize: 10, color: kMuted, letterSpacing: 1)),
          const SizedBox(height: 6),
          TextField(controller: _detCtrl, style: const TextStyle(fontSize: 13),
            decoration: const InputDecoration(hintText: 'Descripción del movimiento')),
          const SizedBox(height: 14),
          const Text('VALOR (COP)', style: TextStyle(fontSize: 10, color: kMuted, letterSpacing: 1)),
          const SizedBox(height: 6),
          TextField(controller: _valCtrl, keyboardType: TextInputType.number,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            style: syneStyle(size: 18),
            decoration: const InputDecoration(prefixText: '\$ ', hintText: '0')),
          const SizedBox(height: 20),
          SizedBox(width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                final val = double.tryParse(_valCtrl.text) ?? 0;
                if (val == 0) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Ingresa un valor'), backgroundColor: kDanger));
                  return;
                }
                final now = DateTime.now();
                prov.addMovimiento(Movimiento(
                  id: now.millisecondsSinceEpoch,
                  fecha: '${now.day}/${now.month}/${now.year}',
                  tipo: _tipo, cat: _cat!, det: _detCtrl.text.trim(), val: val));
                _detCtrl.clear(); _valCtrl.clear();
                FocusScope.of(context).unfocus();
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text('$_tipo registrado ✓'), backgroundColor: kAccent, duration: const Duration(seconds: 2)));
              },
              style: ElevatedButton.styleFrom(backgroundColor: kAccent, foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(vertical: 15),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
              child: Text('Registrar movimiento', style: syneStyle(size: 14, color: Colors.black)),
            )),
        ],
      ))),
    ]);
  }
}

class _TipoBtn extends StatelessWidget {
  final String label; final bool active; final Color color; final VoidCallback onTap;
  const _TipoBtn(this.label, this.active, this.color, this.onTap);
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      decoration: BoxDecoration(
        color: active ? color.withOpacity(0.15) : Colors.transparent,
        border: Border.all(color: active ? color : kBorder),
        borderRadius: BorderRadius.circular(8)),
      child: Text(label, style: TextStyle(color: active ? color : kMuted,
        fontWeight: active ? FontWeight.w700 : FontWeight.w400, fontSize: 13)),
    ),
  );
}
