// lib/screens/resumen_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/mes_selector.dart';
import '../widgets/bolsillo_card.dart';

class ResumenScreen extends StatefulWidget {
  const ResumenScreen({super.key});
  @override
  State<ResumenScreen> createState() => _ResumenScreenState();
}

class _ResumenScreenState extends State<ResumenScreen> {
  final _ctrl = TextEditingController();
  int _lastMes = -1;

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final prov = context.watch<BolsillosProvider>();
    final mes = prov.s.getMes(prov.s.mes);
    if (prov.s.mes != _lastMes) {
      _ctrl.text = mes.bruto > 0 ? mes.bruto.toStringAsFixed(0) : '';
      _lastMes = prov.s.mes;
    }

    return ListView(padding: const EdgeInsets.all(16), children: [
      const MesSelector(),
      const SizedBox(height: 14),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(width: 7, height: 7, decoration: const BoxDecoration(color: kAccent, shape: BoxShape.circle)),
            const SizedBox(width: 8),
            Text('Ingreso del mes', style: syneStyle(size: 13)),
          ]),
          const SizedBox(height: 14),
          const Text('INGRESO BRUTO', style: TextStyle(fontSize: 10, color: kMuted, letterSpacing: 1)),
          const SizedBox(height: 6),
          Row(children: [
            Expanded(child: TextField(
              controller: _ctrl,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              style: syneStyle(size: 20),
              decoration: const InputDecoration(prefixText: '\$ ', hintText: '0'),
            )),
            const SizedBox(width: 8),
            ElevatedButton(
              onPressed: () {
                prov.setIngreso(double.tryParse(_ctrl.text) ?? 0);
                FocusScope.of(context).unfocus();
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                  content: Text('Ingreso actualizado ✓'), backgroundColor: kAccent, duration: Duration(seconds: 2)));
              },
              style: ElevatedButton.styleFrom(backgroundColor: kAccent, foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
              child: Text('Aplicar', style: syneStyle(size: 13, color: Colors.black)),
            ),
          ]),
          const Divider(height: 24),
          Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Seguridad Social', style: syneStyle(size: 13)),
              const Text('Descuenta salud + pensión + ARL', style: TextStyle(fontSize: 11, color: kMuted)),
            ])),
            Switch(value: mes.segActiva, activeColor: kAccent, onChanged: prov.setSegActiva),
          ]),
          if (mes.segActiva) _SegPanel(mes: mes, prov: prov),
        ],
      ))),
      const SizedBox(height: 4),
      Text('DISTRIBUCIÓN', style: syneStyle(size: 11, color: kMuted)),
      const SizedBox(height: 10),
      GridView.builder(
        shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.3),
        itemCount: prov.s.cats.length,
        itemBuilder: (_, i) {
          final cat = prov.s.cats[i];
          return BolsilloCard(cat: cat, data: prov.getSaldos()[cat.n]!);
        },
      ),
    ]);
  }
}

class _SegPanel extends StatelessWidget {
  final MesData mes;
  final BolsillosProvider prov;
  const _SegPanel({required this.mes, required this.prov});

  @override
  Widget build(BuildContext context) {
    final ibc = mes.bruto * 0.4;
    final salud = ibc * tSalud;
    final pension = ibc * tPension;
    final arlVal = ibc * mes.arl;

    return Container(
      margin: const EdgeInsets.only(top: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: kS2, borderRadius: BorderRadius.circular(10), border: Border.all(color: kBorder)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('NIVEL DE RIESGO ARL', style: TextStyle(fontSize: 10, color: kMuted, letterSpacing: 1)),
        const SizedBox(height: 6),
        DropdownButtonFormField<double>(
          value: mes.arl, dropdownColor: kS2,
          style: const TextStyle(color: kText, fontSize: 13, fontFamily: 'DM Mono'),
          decoration: const InputDecoration(),
          items: arlNiveles.map((e) => DropdownMenuItem(value: e['value'] as double, child: Text(e['label'] as String))).toList(),
          onChanged: (v) { if (v != null) prov.setArl(v); },
        ),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: _SI('IBC (40%)', fCOPFull(ibc))),
          const SizedBox(width: 8),
          Expanded(child: _SI('Salud 12.5%', fCOPFull(salud))),
        ]),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: _SI('Pensión 16%', fCOPFull(pension))),
          const SizedBox(width: 8),
          Expanded(child: _SI('ARL', fCOPFull(arlVal))),
        ]),
        const SizedBox(height: 8),
        Align(alignment: Alignment.centerRight, child:
          Text('Descuento: ${fCOPFull(salud+pension+arlVal)}', style: syneStyle(size: 13, color: kDanger))),
        Align(alignment: Alignment.centerRight, child:
          Text('Neto: ${fCOPFull(mes.ingNeto)}', style: syneStyle(size: 12, color: kAccent))),
      ]),
    );
  }
}

class _SI extends StatelessWidget {
  final String label, value;
  const _SI(this.label, this.value);
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(10),
    decoration: BoxDecoration(color: kS1, borderRadius: BorderRadius.circular(8), border: Border.all(color: kBorder)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(fontSize: 10, color: kMuted)),
      const SizedBox(height: 4),
      Text(value, style: syneStyle(size: 12, color: kA3)),
    ]),
  );
}
