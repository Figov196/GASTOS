// lib/widgets/bolsillo_card.dart
import 'package:flutter/material.dart';
import '../models.dart';
import '../theme.dart';

class BolsilloCard extends StatelessWidget {
  final Categoria cat;
  final Map<String, double> data;
  const BolsilloCard({super.key, required this.cat, required this.data});

  @override
  Widget build(BuildContext context) {
    final saldo = data['saldo']!;
    final asignado = data['asignado']!;
    final gastado = data['gastado']!;
    final pctUsado = data['pctUsado']!;
    final neg = saldo < 0;
    final color = Color(cat.color);

    return Container(
      decoration: BoxDecoration(
        color: kS1, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: neg ? kDanger.withOpacity(0.4) : color.withOpacity(0.25)),
      ),
      child: Stack(children: [
        // Color dot indicator
        Positioned(top: 10, right: 10, child: Container(
          width: 6, height: 6,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle))),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 18, 16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: Text(cat.n,
                style: TextStyle(fontSize: 10, color: color.withOpacity(0.8), letterSpacing: 0.8),
                maxLines: 1, overflow: TextOverflow.ellipsis)),
              if (cat.seg) Container(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                decoration: BoxDecoration(color: kA3.withOpacity(0.15), borderRadius: BorderRadius.circular(4)),
                child: const Text('auto', style: TextStyle(fontSize: 8, color: kA3))),
            ]),
            const SizedBox(height: 6),
            Text(fCOP(saldo), style: syneStyle(size: 15, color: neg ? kDanger : kText)),
            const SizedBox(height: 3),
            Text('Asig: ${fCOP(asignado)}', style: const TextStyle(fontSize: 10, color: kA2)),
            const SizedBox(height: 2),
            Text('Gasto: ${fCOP(gastado)}', style: const TextStyle(fontSize: 10, color: kMuted)),
          ]),
        ),
        Positioned(bottom: 0, left: 0, right: 0,
          child: ClipRRect(
            borderRadius: const BorderRadius.only(bottomLeft: Radius.circular(14), bottomRight: Radius.circular(14)),
            child: LinearProgressIndicator(
              value: pctUsado, backgroundColor: kBorder, minHeight: 3,
              valueColor: AlwaysStoppedAnimation(neg ? kDanger : color)))),
      ]),
    );
  }
}
