// lib/widgets/mes_selector.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state.dart';
import '../theme.dart';

const _m = ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];

class MesSelector extends StatelessWidget {
  const MesSelector({super.key});
  @override
  Widget build(BuildContext context) {
    final prov = context.watch<BolsillosProvider>();
    return SizedBox(height: 36, child: ListView.builder(
      scrollDirection: Axis.horizontal, itemCount: 12,
      itemBuilder: (_, i) {
        final active = i == prov.s.mes;
        return GestureDetector(
          onTap: () => prov.setMes(i),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            margin: const EdgeInsets.only(right: 6),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              color: active ? kAccent : Colors.transparent,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: active ? kAccent : kBorder)),
            child: Text(_m[i], style: TextStyle(fontSize: 12, fontFamily: 'DM Mono',
              color: active ? Colors.black : kMuted,
              fontWeight: active ? FontWeight.w700 : FontWeight.w400)),
          ),
        );
      },
    ));
  }
}
